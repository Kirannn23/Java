package com;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.model.employee;

public class App 
{
public static void main(String[] args) {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory factory  =  configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx  = session.beginTransaction();
		employee emp1 = new employee();
		emp1.setName("Kiran");
		emp1.setAge(24);
		emp1.setSalary(30000);
		emp1.setCourse("Java");
		
		employee emp2 = new employee();
		emp2.setName("Pavan");
		emp2.setAge(25);
		emp2.setSalary(15000);
		emp2.setCourse("Apex");
		
		employee emp3 = new employee();
		emp3.setName("Deepak");
		emp3.setAge(26);
		emp3.setSalary(20000);
		emp3.setCourse("OCI");
		
		session.save(emp1);
		session.save(emp2);
		session.save(emp3);
		session.flush();
		
		
		Criteria cr = session.createCriteria(employee.class);
		cr.add(Restrictions.eq("salary", (long)20000));
		List<employee> list = cr.list();
		for(employee e : list)
		{
			System.out.println(e);
		}
		
		tx.commit();
		session.close();
		
	}
}
