package com.model;

public class employee {

	private int eid;
	private String name;
	private int age;
	private long salary;
	private String course;
	
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	@Override
	public String toString() {
		return "employee [eid=" + eid + ", name=" + name + ", age=" + age + ", salary=" + salary + ", course=" + course
				+ "]";
	}
	
	
	
}

