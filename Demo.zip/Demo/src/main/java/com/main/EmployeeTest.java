package com.main;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.model.Employee;

public class EmployeeTest {

	public static void main(String[] args) {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory factory  =  configuration.buildSessionFactory();
		Session session = factory.openSession();
		
		Employee employee = new Employee();
		employee.setName("Kiran");
		employee.setAge(24);
		employee.setSalary(30000);
		employee.setCourse("Java");
		
		session.save(employee);
		
		Transaction tx  = session.beginTransaction();
		tx.commit();
		session.close();
		
	}
}
