package com.main;

import java.util.ArrayList;

import org.hibernate.Session;

import com.model.Book;
import com.model.Library;
import com.util.HibernateUtil;

public class StoreData {

	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		Book b1 = new Book();
		b1.setBookname("Rich Dad Poor Dad");
		b1.setAuthor("Robert Kiyosaki");
		b1.setQuantity(2);
		
		Book b2 = new Book();
		b2.setBookname("Think like a Monk");
		b2.setAuthor("Jay shetty");
		b2.setQuantity(6);
		
		Book b3 = new Book();
		b3.setBookname("Atomic Habits");
		b3.setAuthor("James Clear");
		b3.setQuantity(3);
		
		ArrayList<Book> list = new ArrayList<Book>();
		list.add(b1);
		list.add(b2);
		
		ArrayList<Book> list2 = new ArrayList<Book>();
		list2.add(b1);
		list2.add(b3);
		
		Library library = new Library();
		library.setLibname("Ashoka Lib");
		library.setBooks(list);
		
		Library library2 = new Library();
		library2.setLibname("Main Library");
		library2.setBooks(list2);
		
		session.persist(library);
		session.persist(library2);
		
		session.getTransaction().commit();
		
		session.close();
		
	}
}
