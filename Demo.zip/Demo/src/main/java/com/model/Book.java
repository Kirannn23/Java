package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
public class Book {

	 @Id  
	 @GeneratedValue(strategy=GenerationType.AUTO)  
	    private int bid;    
	 
	 @Column(name="BOOKNAME")
	    private String bookname; 
	 
	 @Column(name="AUTHOR")
	 private String author;
	 
	 @Column(name="QUANTITY")
	 private int quantity;
	 
	public int getId() {
		return bid;
	}

	public void setId(int id) {
		this.bid = id;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
	 
	 
	 
}
