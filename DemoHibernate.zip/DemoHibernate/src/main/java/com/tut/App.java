package com.tut;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        SessionFactory factory  = new Configuration().configure().buildSessionFactory();
        
        System.out.println(factory);
        
        Student student = new Student();
        student.setId(2);
        student.setName("Sanket");
        student.setCity("Nerul");
        System.out.println(student);
        
        
        // address object
        Address address = new Address();
        address.setStreet("M.G.Road");
        address.setCity("Nagpur");
        address.setOpen(true);
        address.setAddedDate(new Date());
        address.setX(323.1212);
        System.out.println(address);
        
        // adsress 2nd data
        Address address2 = new Address();
        address2.setStreet("LBS Road");
        address2.setCity("Mumbai");
        address2.setOpen(false);
        address2.setAddedDate(new Date());
        address2.setX(364.33);
        System.out.println(address2);
        
        Session session = factory.openSession();        
       Transaction tx =  session.beginTransaction();
       
        session.save(student);
        session.save(address);
        session.save(address2);
        
        tx.commit();
        session.close();
        
        
    }
}
