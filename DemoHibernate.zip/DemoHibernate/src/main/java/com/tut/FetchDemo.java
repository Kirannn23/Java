package com.tut;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FetchDemo {
	public static void main(String[] args) {
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		
		Session session = factory.openSession();
		
		Student student  = (Student) session.load(Student.class, 2);
		//Student student1  = (Student) session.load(Student.class, 2);
		System.out.println(student.getCity());
		//System.out.println(student1);
		
		/*Address address = (Address)session.load(Address.class, 3);
		System.out.println("sdgsygd"+address);
		System.out.println("sgdshd");*/
		session.close();
		factory.close();
		
	}
}
